import { PanelBase } from "../../ui/panel/PanelBase";
import { TablePanel } from "../../ui/panel/TablePanel";
import { DateBoxInput } from "../../ui/input/DateBoxInput";
import { TextBoxInput } from "../../ui/input/TextBoxInput";
import { LookupBoxInput } from "../../ui/input/LookupBoxInput";
import { Validators } from "@angular/forms";
import { ButtonInput } from "../../ui/input/ButtonInput";
import { CheckBoxInput } from "../../ui/input/CheckBoxInput";
import { NumberBoxInput } from "../../ui/input/NumberBoxInput";
import { IEditorFormulaDeclaration } from ".././IEditorDeclare";
import { IExplorerFormulaDeclaration } from ".././IExplorerDeclare";
import { UploadInput } from "../../ui/input/UploadInput";
import { MultiSelectInput } from "../../ui/input/MultiSelectInput";
import { SystemConstants } from "../../core/common/system.constants";
import { UploadImage } from "../../ui/input/UploadImage";
import { getElement } from "wijmo/wijmo";
import { RichTextBoxInput } from "../../ui/input/RichTextBoxInput";
import { Global } from "../../shared/global";

export class LayoutApprovedPlanCashFlowSiteEditor implements IEditorFormulaDeclaration {

    buttonLoadChild: string[];
    serverUpdated: string[];
    buttonCommand: string[];
    constructor(private srv?: any,
        private parentData?: any) { }

    evaluators = {
        'Evaluator_ServerUpdating_UpdateStatusByApproveStatus': {
            EvaluatorName: 'EvaluatorQuery',
            ConstraintKey: 'BizDocId,Id,ApproveStatus,{VAR=Branch.Ma_Dvcs},EmployeeCodeNext,DocCode,{VAR=User.Id},Comment,ApproveStatusWeb',
            Command: 'usp_Cotec_UpdateStatusByApproveStatus_SongSong'
        }
    };

    approveGrid = 1;

    serverConstraint = [
    ]

    serverUpdating = [

    ]

    columnChanged = {

    };

    linkReporter = {
        'btnBaoCao': {
            directory: 'reporterplancashflowsite',
            type: 'view',
            key: 'REP_ProjectCashFlow',
            parameter: { 'Commandkey': 'REP_ProjectCashFlow', 'ProductCostId': '{EXPR=ProductCostId}', 'CCMBudgetId': '{EXPR=CCMBudgetId}', 'BranchCode': '{VAR=Branch.Ma_Dvcs}' }
        }
    }

    columnsReadOnly = [];

    layout = {
        Structure: {
            Parent: {
                Name: 'vB30BizDocApprove_CCMBudgetEditK6',
                DefaultValues: {
                    BranchCode: '{VAR=Branch.Ma_Dvcs}',
                    DocCode: 'K3',
                    CCMBudgetId: '',
                    CurrencyCode: 'VND',
                    Id: -1
                }
            },
            Child: [
                {
                    Name: 'vB30CCMBudgetDetail_Edit',
                    ParentKey: 'BizDocId',
                    ChildKey: 'CCMBudgetId',
                    Sort: 'BuiltinOrder',
                    DefaultValues: {
                        CCMBudgetId: '',
                        BuiltinOrder: '1',
                        DocDate: 'Parent.DocDate'
                    }
                },
                {
                    Name: 'vB30BizDocApproveLog_Edit',
                    ParentKey: 'BizDocId',
                    ChildKey: 'BizDocId',
                    Sort: 'BuiltinOrder',
                    DefaultValues: {
                        BizDocId: '',
                        BuiltinOrder: '1',
                        DocDate: 'Parent.DocDate'
                    }
                },
                {
                    Name: 'vB30BizDocApprove_AEditBudget',
                    ParentKey: 'CCMBudgetId',
                    ChildKey: 'BizDocId',
                    Sort: 'BuiltinOrder',
                    DefaultValues: {
                        BizDocId: 'Parent.CCMBudgetId',
                        BuiltinOrder: '1',
                        DocDate: 'Parent.DocDate'
                    }
                },
                {
                    Name: 'vB30BizDocDocument',
                    ParentKey: 'CCMBudgetId',
                    ChildKey: 'BizDocId',
                    DefaultValues: {
                        BizDocId: 'Parent.CCMBudgetId',
                        BuiltinOrder: '1',
                        DocDate: 'Parent.DocDate',
                    }
                },
                {
                    Name: 'vB30CCMBudgetDetail1_Edit',
                    ParentKey: 'CCMBudgetId',
                    ChildKey: 'CCMBudgetId',
                    // Sort: 'BuiltinOrder',
                    DefaultValues: {
                        CCMBudgetId: 'Parent.CCMBudgetId',
                        DocDate: 'Parent.DocDate',
                        BranchCode: '{VAR=Branch.Ma_Dvcs}',
                        Quantity9: '0'
                    }
                }
            ]
        },
        PrintDocument: {
            Key: 'CCMBudgetViewer',
            Text: 'Kế hoạch ký kết hợp đồng - {VAR=ProductName} - {VAR=DocNo}',
            Command: 'usp_B30CCMBudget_VoucherForm',
            LayoutPrint: [
                {
                    Layout: "MAU1",
                    Name: "Kế hoạch ký kết hợp đồng",
                    FileName: "Kế hoạch ký kết hợp đồng - {EXPR=ProductName} - {EXPR=DocNo}",
                    WordName: "1.Ke_Hoach_Ky_Ket_Hop_Dong_XemDuyet.docx",
                    FolderPath: "/3.Mau_In/{VAR=Branch.Ma_Dvcs}/"
                }
            ],
            PrintGrid: [
            ]
        }
    };

    panels: PanelBase[] = [
        new TablePanel({
            label: 'Panel 1',
            col: 12,
            controls: [
                new DateBoxInput({
                    key: 'DateSend',
                    label: 'Ngày gửi duyệt',
                    type: 'date',
                    format: 'dd/MM/yyyy',
                    validators: [Validators.required],
                    col: 6,
                    isReadOnly: 'true',
                    style: 'background-color:#F1EDED;border-radius:8px;'
                }),
                new TextBoxInput({
                    key: 'DocNo',
                    label: 'Số kế hoạch',
                    type: 'text',
                    validators: [Validators.required],
                    col: 6,
                    isReadOnly: 'true',
                    style: 'background-color:#F1EDED;border-radius:8px;'
                }),
                new LookupBoxInput({
                    key: 'ProductCostId',
                    label: 'Gói thầu/Phòng, ban',
                    lookupKey: 'ProductCost',
                    binding: {
                    },
                    // lookupfilter: "IsGroup=0 AND IsActive=1 AND ProductType IN (1,3) AND BranchCode='{VAR=Branch.Ma_Dvcs}' AND RowId = '{VAR=Filter.ProductCostId}'",
                    validators: [Validators.required],
                    hideValueMember: true,
                    isReadOnly: 'true',
                    style: 'background-color:#F1EDED;border-radius:8px;',
                    col: 12
                }, this.srv, this.parentData),
                new LookupBoxInput({
                    key: 'ProcessCode',
                    label: 'Quy trình duyệt',
                    lookupKey: 'Approve',
                    lookupfilter: "IsActive=1",
                    validators: [Validators.required],
                    hideValueMember: false,
                    isReadOnly: 'true',
                    style: 'background-color:#F1EDED;border-radius:8px;',
                    col: 12
                }, this.srv, this.parentData),
                new NumberBoxInput({
                    key: 'TotalAmountBill',
                    label: 'Tổng DOANH THU',
                    type: 'number',
                    col: 6,
                    isReadOnly: 'true',
                    style: 'background-color:#F1EDED;border-radius:8px;'
                }),
                new NumberBoxInput({
                    key: 'Amount_DoanhThu',
                    label: 'Tổng THU',
                    type: 'number',
                    col: 6,
                    isReadOnly: 'true',
                    style: 'background-color:#F1EDED;border-radius:8px;'
                }),
                new NumberBoxInput({
                    key: 'Amount_ChiPhi',
                    label: 'Tổng CHI',
                    type: 'number',
                    col: 6,
                    isReadOnly: 'true',
                    style: 'background-color:#F1EDED;border-radius:8px;'
                }),
                new NumberBoxInput({
                    key: 'Amount_LoiNhuan',
                    label: 'Thu - Chi',
                    style: 'background-color:#F8F0D7;border-radius:8px;',
                    isReadOnly: 'true',
                    col: 6,
                    
                }),
                new UploadInput({
                    key: 'FilePath',
                    label: 'Đính kèm',
                    col: 6,
                    isOnlyDownload: true,
                    // folderId: '{EXPR=IdCCMBudget}'
                }, this.srv),
                new DateBoxInput({
                    key: 'ToDate',
                    label: 'Ngày h.thành thi công cập nhật',
                    type: 'date',
                    format: 'dd/MM/yyyy',
                    
                    col: 6
                }),
                new NumberBoxInput({
                    key: 'NumberOfDays',
                    label: 'Số ngày thực hiện',
                    type: 'number',
                    dataType: 'n0',
                    
                    isDisabled: 'true',
                    col: 6
                }),
                new LookupBoxInput({
                    key: 'DeptCode',
                    label: 'Bộ phận',
                    lookupKey: 'Dept',
                    hideValueMember: false,
                    isDisabled: 'true',
                    col: 6
                }, this.srv, this.parentData),
                new LookupBoxInput({
                    key: 'PositionCode',
                    label: 'Cấp bậc duyệt',
                    lookupKey: 'Position',
                    hideValueMember: false,
                    isDisabled: 'true',
                    col: 6
                }, this.srv, this.parentData),
                new LookupBoxInput({
                    key: 'EmployeeCode',
                    label: 'Người duyệt',
                    lookupKey: 'Employee',
                    hideValueMember: false,
                    isDisabled: 'true',
                    col: 6
                }, this.srv, this.parentData),
                new RichTextBoxInput({
                    key: 'Reason',
                    label: 'Nguyên nhân âm thu chi sâu',
                    
              
                    col: 12
                }),
                new RichTextBoxInput({
                    key: 'Remedy',
                    label: 'Biện pháp khắc phục',
                    
                    
                    col: 12
                }),
                // new LookupBoxInput({
                //     key: 'InformMethod',
                //     label: 'Kiểu thông báo',
                //     lookupKey: 'Class',
                //     lookupfilter: "ParentCode='InformMethod'",
                //     hideValueMember: false,
                //     isDisabled: 'true',
                //     style: 'background-color:#F1EDED;border-radius:8px;',
                //     col: 6
                // }, this.srv, this.parentData),
                new RichTextBoxInput({
                    key: 'Comment',
                    label: 'Ý kiến',
                    col: 12
                }),
                // new ButtonInput({
                //     key: 'btnBaoCao',
                //     label: 'Báo cáo điều chỉnh kế hoạch ký kết',
                //     col: 6
                // }),
               
                new LookupBoxInput({
                    key: 'EmployeeCodeSend',
                    label: 'Người gửi duyệt',
                    lookupKey: 'Employee',
                    hideValueMember: false,
                    col: 6,
                    isDisabled: 'true'
                }, this.srv, this.parentData),
                new CheckBoxInput({
                    key: 'IsGeneralDirector',
                    label: 'Quy trình qua TGĐ',
                    col: 6,
                    isDisabled: 'true',
                    isNewRow: true
                }),
                new ButtonInput({
                    key: 'btnBaoCao',
                    label: 'Báo cáo Doanh thu - Dòng tiền',
                    col: 6
                }),
                // new NumberBoxInput({
                //     key: 'IdCCMBudget',
                //     label: 'Số ngày thực hiện',
                //     type: 'number',
                //     dataType: 'n0',
                //     // visible: 'false',
                //     // isDisabled: 'true',
                //     // isNewRow: true,
                //     col: 6
                // }),
             
            ]
        })
    ];

    childColumns = [
        {
            header: 'Thời gian',
            binding: 'EstimatedTimeDelivery',
            isRequired: true,
            width: 120,
            dataType: 'Date',
            format: 'dd/MM/yyyy'
        },
        {
            header: 'Khối lượng thi công',
            binding: 'Amount_ThiCong',
            dataType: 'Number',
            width: 200
        },
        {
            header: 'Khối lượng thi công - XD',
            binding: 'Amount_ThiCongXD',
            dataType: 'Number',
            width: 150
        },
         {
            header: 'Khối lượng thi công - NSC XD',
            binding: 'ThiCong_NSC_XD',
            dataType: 'Number',
            width: 150
        },
        
        {
            header: 'Khối lượng thi công - ME',
            binding: 'Amount_ThiCongME',
            dataType: 'Number',
            width: 150
        },
         {
            header: 'Khối lượng thi công - NSC ME',
            binding: 'ThiCong_NSC_ME',
            dataType: 'Number',
            width: 150
        },
         {
            header: 'Khối lượng thi công - HST',
            binding: 'ThiCong_HST',
            dataType: 'Number',
            width: 150
        },
        {
            header: 'Kế hoạch DOANH THU',
            binding: 'OpenPlanAmount',
            dataType: 'Number',
            width: 200
        },
        {
            header: 'Kế hoạch DOANH THU - XD',
            binding: 'OpenPlanAmountXD',
            dataType: 'Number',
            width: 200
        },
          {
            header: 'Kế hoạch DOANH THU - NSC XD',
            binding: 'DoanhThu_NSC_XD',
            dataType: 'Number',
            width: 150
        },
        {
            header: 'Kế hoạch DOANH THU - ME',
            binding: 'OpenPlanAmountME',
            dataType: 'Number',
            width: 200
        },
          {
            header: 'Kế hoạch DOANH THU - NSC ME',
            binding: 'DoanhThu_NSC_ME',
            dataType: 'Number',
            width: 150
        },
         {
            header: 'Kế hoạch DOANH THU - HST',
            binding: 'DoanhThu_HST',
            dataType: 'Number',
            width: 150
        },
        {
            header: 'Kế hoạch THU',
            binding: 'OriginalAmount',
            dataType: 'Number',
            width: 200
        },
        {
            header: 'Thực tế THU',
            binding: 'OriginalAmountBak',
            dataType: 'Number',
            width: 200,
            exprReadOnly: "{EXPR=IsOld} != '0' || {EXPR=IsOld} != ''"
        },
        {
            header: 'Kế hoạch CHI',
            binding: 'PaymentAmount',
            dataType: 'Number',
            width: 200,
            
        },   
        {
            header: 'Thực tế chi',
            binding: 'PaymentAmountBak',
            dataType: 'Number',
            width: 200,
            exprReadOnly: "{EXPR=IsOld} != '0' || {EXPR=IsOld} != ''"
        },  
        {
            header: 'THU - CHI',
            binding: 'Amount',
            dataType: 'Number',
            width: 200,
            isReadOnly: 'true'
        },
        {
            header: 'Lũy kế THU',
            binding: 'AmountLNKT_KT',
            dataType: 'Number',
            width: 200,
            isReadOnly: 'true'
        }, 
        {
            header: 'Lũy kế CHI',
            binding: 'AmountLNCT_KT',
            dataType: 'Number',
            width: 200,
            isReadOnly: 'true'
        },
        {
            header: 'Lũy kế THU - CHI',
            binding: 'AcumDiscountAmount',
            dataType: 'Number',
            width: 200,
            isReadOnly: 'true'
        },
        {
            header: 'Lũy kế THU kỳ trước',
            binding: 'OriginalAmount1',
            dataType: 'Number',
            width: 200,
            isReadOnly: 'true'
        }, 
        {
            header: 'Lũy kế CHI kỳ trước',
            binding: 'OriginalAmount2',
            dataType: 'Number',
            width: 200,
            isReadOnly: 'true'
        },
        {
            header: 'Lũy kế THU - CHI kỳ trước',
            binding: 'OriginalAmount3',
            dataType: 'Number',
            width: 200,
            isReadOnly: 'true'
        },
          {
            header: 'Ghi chú',
            binding: 'Remark',
            width: 300
        }   ,
        {
            header: 'Kế hoạch THU',
            binding: 'OriginalAmountBak',
            dataType: 'Number',
            width: 0
        },    
        {
            header: 'Kế hoạch CHI',
            binding: 'PaymentAmountBak',
            dataType: 'Number',
            width: 0
        } ,
        {
            header: 'Kế hoạch THU',
            binding: 'OriginalAmount4',
            dataType: 'Number',
            width: 0
        },    
        {
            header: 'Kế hoạch CHI',
            binding: 'OriginalAmount5',
            dataType: 'Number',
            width: 0
        }                                                                               
        // {
        //     header: 'Dòng tiêu đề',
        //     binding: 'IsTitleRow',
        //     dataType: 'Boolean',
        //     width: 0,
        //     isReadOnly: 'true'
        // },
        // {
        //     header: 'Bậc',
        //     binding: 'Level',
        //     dataType: 'Number',
        //     width: 0,
        //     format: 'n0',
        //     isReadOnly: 'true'
        // },
        // {
        //     header: 'Công thức',
        //     binding: 'Formula',
        //     width: 0,
        //     isReadOnly: 'true'
        // }
    ];

    childColumns1 = [
        {
            header: 'STT',
            binding: 'ApproveGroup',
            dataType: 'Number',
            width: 50,
            align: 'center',
        },
        {
            header: 'Cấp bậc duyệt',
            binding: 'PositionName',
            width: 250
        },
        {
            header: 'Người thực hiện',
            binding: 'EmployeeName',
            width: 230
        },
        {
            header: 'Trạng thái',
            binding: 'ApproveStatusName',
            width: 100
        },
        {
            header: 'Ý kiến',
            binding: 'Comment',
            width: 250,
            isContentHtml: true,
            wordWrap: true
        },
        {
            header: 'Ngày đến hạn',
            binding: 'StartDate',
            width: 150,
            dataType: 'Date',
            format: 'dd/MM/yyyy HH:mm'
        },
        {
            header: 'Ngày hoàn thành',
            binding: 'FinishDate',
            dataType: 'Date',
            format: 'dd/MM/yyyy HH:mm',
            width: 150
        }
    ];

    childColumns2 = [
        {
            header: 'STT',
            binding: 'ApproveGroup',
            dataType: 'Number',
            width: 50,
            align: 'center',
            isReadOnly: 'true'

        },
        {
            header: 'Mã bộ phận',
            binding: 'DeptCode',
            isRequired: true,
            dataType: 'Array',
            lookupKey: 'Dept',
            lookupfilter: 'IsGroup=0 AND IsActive=1',
            width: 0,
            isReadOnly: 'true'
        },
        // {
        //     header: 'Bộ phận',
        //     binding: 'DeptName',
        //     width: 300,
        //     isReadOnly: 'true'
        // },
        {
            header: 'Mã cấp bậc',
            binding: 'PositionCode',
            dataType: 'Array',
            lookupKey: 'Position',
            lookupfilter: 'IsGroup=0 AND IsActive=1',
            width: 0,
            isReadOnly: 'true'
        },
        {
            header: 'Cấp bậc duyệt',
            binding: 'PositionName',
            width: 250,
            isReadOnly: 'true'
        },
        {
            header: 'Mã nhân viên',
            binding: 'EmployeeCode',
            width: 100,
            dataType: 'Array',
            lookupKey: 'Employee',
            lookupfilter: "IsActive=1 AND Code IN (SELECT EmployeeCode FROM B20ProductHuman WHERE IsActive = 1 AND ProductCostId='{EXPR=ProductCostId}' AND PositionCode = '{EXPR=PositionCode}')",
            validators: "{EXPR=EmployeeCode} == ''",
            validatorMessage: 'Không được bỏ trống giá trị',
            ignoreError: 1
        },
        {
            header: 'Tên nhân viên',
            binding: 'EmployeeName',
            width: 150,
            isReadOnly: 'true'
        },
        {
            header: 'Người duyệt được chỉ định',
            binding: 'EmployeeCodeReal',
            dataType: 'Array',
            lookupKey: 'Employee',
            lookupfilter: "IsActive=1 AND Code IN (SELECT EmployeeCode FROM B20ProductHuman WHERE IsActive = 1 AND ProductCostId='{EXPR=ProductCostId}' AND PositionCode = '{EXPR=PositionCode}')",
            width: 120,
            validators: "{EXPR=EmployeeCode} != '' && {EXPR=EmployeeCode}.toString().indexOf(',') > 0 && {EXPR=EmployeeCodeReal} == ''",
            validatorMessage: 'Không được bỏ trống giá trị',
            ignoreError: 1
        },
        {
            header: 'Số ngày xử lý',
            binding: 'NumberOfDays',
            dataType: 'Number',
            width: 100,
            isReadOnly: 'true'
        },
        {
            header: 'Ngày đến hạn',
            binding: 'StartDate',
            width: 150,
            dataType: 'Date',
            format: 'dd/MM/yyyy HH:mm'
        },
        {
            header: 'Ngày hoàn thành',
            binding: 'FinishDate',
            dataType: 'Date',
            format: 'dd/MM/yyyy HH:mm',
            width: 150
        },         
        {
            header: 'Được trả hồ sơ',
            binding: 'ApproveReturn',
            width: 100,
            dataType: 'Boolean',
            isReadOnly: 'true'
        },
        // {
        //     header: 'Trả về cấp bậc',
        //     binding: 'PositionCodeReturn',
        //     width: 100,
        //     isReadOnly: 'true'
        // }
    ];

    childColumns3 = [
        {
            header: 'Ghi chú',
            binding: 'Description',
            width: 250
        },
        {
            header: 'File đính kèm',
            binding: 'FilePath',
            width: 500,
            dataType: 'Object',
            folderId: '{EXPR=IdCCMBudget}'
            // //validators: "{EXPR=Description} != '' && {EXPR=Description} == 'Yêu cầu đính kèm' && {EXPR=FilePath}==0",
            // validators: "{EXPR=Attached} == true && {EXPR=Description} != 'Theo mẫu công ty ban hành' && {EXPR=FilePath}==0",
            // validatorMessage: 'Yêu cầu đính kèm tài liệu',
            // ignoreError: 1
            // //exprReadOnly: "{EXPR=Attached} == true && {EXPR=Description} != ''"
        }
    ];
    childColumns4 = [
        {
            header: 'STT',
            binding: 'BuiltinOrder',
            width: 60,
            isReadOnly: 'true'
        },
        {
            header: 'Nội dung',
            binding: 'Description',
            width: 200
        },
      
        {
            header: 'Tổng Thu',
            binding: 'OriginalAmount',
            dataType: 'Number',
            isReadOnly: 'true',
            width: 200
        },
        {
            header: 'Thu NSC',
            binding: 'OriginalAmount1',
            dataType: 'Number',
            width: 200
        },
        {
            header: 'Thu New',
            binding: 'OriginalAmount2',
            dataType: 'Number',
            width: 200
        },
        {
            header: 'Tổng Chi',
            binding: 'PaymentAmount',
            dataType: 'Number',
            isReadOnly: 'true',
            width: 200
        },   
        {
            header: 'Chi NSC',
            binding: 'OriginalAmount4',
            dataType: 'Number',
            width: 200
        },
        {
            header: 'Chi New',
            binding: 'OriginalAmount5',
            dataType: 'Number',
            width: 200
        },
       
        {
            header: 'Lũy kế chênh lệch',
            binding: 'AcumDiscountAmount',
            dataType: 'Number',
            width: 200,
            isReadOnly: 'true'
        },
        {
            header: 'Chênh lệch được duyệt',
            binding: 'OpenPlanAmount',
            dataType: 'Number',
            width: 200
        }
     
    ];
}